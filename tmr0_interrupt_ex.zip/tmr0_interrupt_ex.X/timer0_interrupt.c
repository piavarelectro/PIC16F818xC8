/*
 * PIC16F818 Timer0 Interrupt
 * Programming Example
 */

#include <xc.h>

// PIC16F818 Configuration Bit Settings

// CONFIG
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = ON       // RA5/MCLR/VPP Pin Function Select bit (RA5/MCLR/VPP pin function is MCLR)
#pragma config BOREN = ON       // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = ON         // Low-Voltage Programming Enable bit (RB3/PGM pin has PGM function, Low-Voltage Programming enabled)
#pragma config CPD = OFF        // Data EE Memory Code Protection bit (Code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off)
#pragma config CCPMX = RB2      // CCP1 Pin Selection bit (CCP1 function on RB2)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)


void main(void){

    /*Clear Port B*/
    PORTB=0x00;
    /*Port B As Digital Output*/
    TRISB=0x00;
    /*Select Timer0 Prescaler*/
    PSA=0;
    /*Select timer mode*/
    T0CS=0;
    /*Select 1:256 Prescaler*/
    OPTION_REGbits.PS=0x07;
    /*Enable Global Interrupt*/
    GIE=1;
    /*Enable Timer0 Overflow Interrupt*/
    TMR0IE=1;
    /*Clear Timer0 register*/
    TMR0=0;
    /*Clear Timer0 Overflow Interrupt Flag*/
    TMR0IF=0;
    /*Main program loop contain void of codes*/
    while(1);
}

void interrupt timer0ISR(void){
    /*Check for Timer0 overflow*/
    if(TMR0IF){
        /*Clear overflow flag*/
        TMR0IF=0;
        RB0^=1;
    }
}
