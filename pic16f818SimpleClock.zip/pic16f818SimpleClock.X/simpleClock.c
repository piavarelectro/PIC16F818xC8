/*
 * PIC16F818 Simple 7-Segments
 * multiplexing display clock
 */
#include <xc.h>
#include "pic16f818Config.h"

#define MININC RA4
#define MINDEC RA5
#define SECINC RA6
#define SECDEC RA7

#define maxPress 200

void ioInit(void);
void timer0Init(void);
void ssdDisplay(void);
void timeAdjust(void);
unsigned long getOneSecond(void);

unsigned long t0Counter=0;
unsigned long micro_100=0;

unsigned char oneSecond=0;
unsigned char buttonTime=0;
unsigned char minute=12;

char blinker=0xFF;

void main(void){
    unsigned long oneSecond=0;
    ioInit();
    timer0Init();
    while(1){
        oneSecond=getOneSecond();
        timeAdjust();
        ssdDisplay();
    }
}

/*Digital IO and Clock Set Up*/
void ioInit(void){
    /*Clear IO*/
    PORTA=0x00;
    PORTB=0x00;
    /*Port A higher nibble is digital input*/
    TRISA=0xF0;
    /*Port B as output*/
    TRISB=0x00;
    /*Turn on Pull Up Resistors*/
    nRBPU=0;
    /*Clear Analog function on Port A*/
    ADCON1=0x06;
    /*Set up internal oscillator*/
    OSCCONbits.IRCF=0x07;
}

/*Timer 0 Set Up Section*/
void timer0Init(void){
    /*Select internal timer mode*/
    T0CS=0;
    /*Select Timer0 Prescaler*/
    PSA=0;
    /*Select 1:2 Timer0 Rate*/
    OPTION_REGbits.PS=0x00;
    /*Enable Timer0 Interrupt*/
    TMR0IE=1;
    /*Turn On Global Interrupt*/
    GIE=1;
    /*Clear Timer0 Interrupt Flag*/
    TMR0IF=0;
    /*Clear Timer0*/
    TMR0=0;
}

/*Get one second routine*/
unsigned long getOneSecond(void){
    
    if(t0Counter>=10000){
        oneSecond+=1;
        blinker^=0x80;
        blinker|=0b01111111;
        t0Counter=0;
    }
    return oneSecond;
}

/*Multiplexing Display Routine*/
void ssdDisplay(void){
    /*common anode display pattern*/
    char anodePattern[16]={192,249,164,176,153,146,130,248,128,144,136,131,198,161,134,142};
    static unsigned char oneMilli=0;
    if(micro_100>=10){
        oneMilli+=1;
        micro_100=0;
        buttonTime+=1;
    }
    if(oneMilli>20){
        oneMilli=0;
    }

    if(oneSecond>=60){
        oneSecond=0;
        minute+=1;
        if(minute>=60) minute=0;
    }

    /*Driving multiplexing display*/
    switch(oneMilli){
        case 0:
            PORTA=0x00;
            PORTB=anodePattern[oneSecond%10]&blinker;
            PORTA=0x08;
            break;

        case 5:
            PORTA=0x00;
            PORTB=anodePattern[oneSecond/10]&blinker;
            PORTA=0x04;
            break;

        case 10:
            PORTA=0x00;
            PORTB=anodePattern[minute%10]&blinker;
            PORTA=0x02;
            break;

        case 15:
            PORTA=0x00;
            PORTB=anodePattern[minute/10]&blinker;
            PORTA=0x01;
            break;
    }
}

/*Adjusting Time*/
void timeAdjust(void){
    /*Checking digital inputs*/
    if(buttonTime>=maxPress){
        if(MININC==0){
            if(minute<60) minute++;
            buttonTime=0;
        }
        if(MINDEC==0){
            if(minute>0) minute--;
            buttonTime=0;
        }
        if(SECINC==0){
            if(oneSecond<60) oneSecond++;
            buttonTime=0;
        }
        if(SECDEC==0){
            if(oneSecond>0) oneSecond--;
            buttonTime=0;
        }
    }
}

/*Interrupt Service Routine*/
void interrupt _myISR(void){
    /*Check Timer0 Interrupt Flag*/
    if(TMR0IE&&TMR0IF){
        TMR0=-100;   
        t0Counter+=1;
        micro_100+=1;
        
        TMR0IF=0;
    }
}