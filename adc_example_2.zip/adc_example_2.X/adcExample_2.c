
/*
 * PIC16F818 A/D Converter Example 2
 * A/D reading bargraph display
 */
#include <xc.h>
#include "pic16f818_config.h"

/*Set oscillator to 8MHz*/
#define _XTAL_FREQ  8000000

void main(void){
    /*LED Bar Graph Representation*/
    char barGraph[9]={0,0b00000001,0b00000011,0b00000111,0b00001111,
        0b00011111,0b00111111,0b01111111,0b11111111};
    /*Select 8MHz internal oscillator*/
    OSCCONbits.IRCF=0x07;
    /*Clear Port A*/
    PORTA=0x00;
    /*Clear Port B*/
    PORTB=0x00;
    /*RA0 analog input*/
    TRISA=0x01;
    /*Port B digital output*/
    TRISB=0x00;
    /*Select internal RC oscillator of A/D converter*/
    ADCON0bits.ADCS=0x01;
    /*Select analog channel 0 - AN0*/
    ADCON0bits.CHS=0x00;
    /*RA0-AN0 analog input, AVDD and AVSS voltage references*/
    ADCON1bits.PCFG=14;
    /*Result is right justified*/
    ADCON1bits.ADFM=1;
    /*Turn on A/D converter module*/
    ADCON0bits.ADON=1;
    /*Main Program Loop*/
    while(1){
        /*Start the conversion*/
        ADCON0bits.GO_nDONE=1;
        /*When GO_nDONE is clear A/D conversion is completed*/
        while(GO_nDONE);
        /*Wait for some microseconds*/
        for(int i=0;i<1000;i++);
        /*Make a 10-bit A/D converter result*/
        int _L=ADRESL;
        int _H=ADRESH;
        unsigned int barValue=(_H<<8)+_L;
        /*Convert A/D result to 9 values*/
        barValue=(float)barValue*9.0/1024;
        /*Display bargraph on Port B*/
        PORTB = barGraph[barValue];
    }
}