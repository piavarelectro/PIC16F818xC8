/*
 * Internal oscillator example
 * with digital input
 */
#include <xc.h>

// PIC16F818 Configuration Bit Settings
// CONFIG
#pragma config FOSC = INTOSCIO  // Oscillator Selection bits (INTRC oscillator; port I/O function on both RA6/OSC2/CLKO pin and RA7/OSC1/CLKI pin)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = ON       // RA5/MCLR/VPP Pin Function Select bit (RA5/MCLR/VPP pin function is MCLR)
#pragma config BOREN = ON       // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = OFF        // Low-Voltage Programming Enable bit (RB3/PGM pin has digital I/O function, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EE Memory Code Protection bit (Code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off)
#pragma config CCPMX = RB2      // CCP1 Pin Selection bit (CCP1 function on RB2)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

#define toggleButton    RA6
#define toggleLed       RA7

void main(void){

    /*Use its maximum 8MHz internal oscillator*/
    OSCCONbits.IRCF=0x07;
    /*Clear Port B*/
    PORTB=0x00;
    /*RB0 outputs to LED*/
    TRISBbits.TRISB0=0;
    /*Clear Port A*/
    PORTA=0x00;
    /*RA6 button input*/
    TRISAbits.TRISA6=1;
    /*RA7 output*/
    TRISAbits.TRISA7=0;
    /*Program loop*/
    while(1){
        /*Check digital input state*/
        if(toggleButton==0){
            /*Wait for button press is released*/
            while(toggleButton==0);
            toggleLed^=1;
        }
        /*RB0 is high whenever the oscillator is stable*/
        RB0=IOFS;
    }
}