/*
 * A/D converter example of PIC16F818
 * programming using MPLABX XC8
 */

#include <xc.h>

// PIC16F818 Configuration Bit Settings

// CONFIG
#pragma config FOSC = INTOSCIO  // Oscillator Selection bits (INTRC oscillator; port I/O function on both RA6/OSC2/CLKO pin and RA7/OSC1/CLKI pin)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = ON       // RA5/MCLR/VPP Pin Function Select bit (RA5/MCLR/VPP pin function is MCLR)
#pragma config BOREN = ON       // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = OFF         // Low-Voltage Programming Enable bit (RB3/PGM pin has PGM function, Low-Voltage Programming enabled)
#pragma config CPD = OFF        // Data EE Memory Code Protection bit (Code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off)
#pragma config CCPMX = RB2      // CCP1 Pin Selection bit (CCP1 function on RB2)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

void main(void){   
    /*Select 8MHz internal oscillator*/
    OSCCONbits.IRCF=0x07;
    /*Clear Port A*/
    PORTA=0x00;
    /*Clear Port B*/
    PORTB=0x00;
    /*RA0 analog input*/
    TRISA=0x01;
    /*Port B digital output*/
    TRISB=0x00;
    /*Select internal RC oscillator of A/D converter*/
    ADCON0bits.ADCS=0x01;
    /*Select analog channel 0 - AN0*/
    ADCON0bits.CHS=0x00;
    /*RA0-AN0 analog input, AVDD and AVSS voltage references*/
    ADCON1bits.PCFG=14;
    /*Result is right justified*/
    ADCON1bits.ADFM=1;
    /*Turn on A/D converter module*/
    ADCON0bits.ADON=1;
    /*Main Program Loop*/
    while(1){
        /*Start the conversion*/
        ADCON0bits.GO_nDONE=1;
        /*When GO_nDONE is clear A/D conversion is completed*/
        while(GO_nDONE);
        /*Wait for some microseconds*/
        for(int i=0;i<1000;i++);
        /*Make a 10-bit A/D converter result*/
        int _L=ADRESL;
        int _H=ADRESH;
        int result = (_H<<8)+_L;
        /*If analog voltage is more than half RB4 is set*/
        RB7 = (result>=512)?1:0;
    }
}